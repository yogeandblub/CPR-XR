// Adds the Android permissions QuestCallBridge needs to the generated Gradle
// project, so teammates don't have to edit AndroidManifest.xml by hand.
#if UNITY_ANDROID
using System.IO;
using System.Xml;
using UnityEditor.Android;
using UnityEngine;

public class QuestCallBridgeManifestPatcher : IPostGenerateGradleAndroidProject
{
    private const string AndroidNs = "http://schemas.android.com/apk/res/android";

    private static readonly string[] Permissions =
    {
        "android.permission.INTERNET",
        "android.permission.RECORD_AUDIO",
        "android.permission.MODIFY_AUDIO_SETTINGS",
    };

    public int callbackOrder => 100;

    public void OnPostGenerateGradleAndroidProject(string path)
    {
        // 'path' is the unityLibrary module.
        string manifestPath = Path.Combine(path, "src", "main", "AndroidManifest.xml");
        if (!File.Exists(manifestPath))
        {
            Debug.LogWarning("[QuestCallBridge] AndroidManifest.xml not found at " + manifestPath +
                             ". Add RECORD_AUDIO, MODIFY_AUDIO_SETTINGS and INTERNET permissions manually.");
            return;
        }

        var doc = new XmlDocument();
        doc.Load(manifestPath);
        XmlElement root = doc.DocumentElement;
        if (root == null) return;

        int added = 0;
        foreach (string perm in Permissions)
        {
            bool exists = false;
            foreach (XmlNode n in root.SelectNodes("uses-permission"))
            {
                var a = n.Attributes?["name", AndroidNs];
                if (a != null && a.Value == perm) { exists = true; break; }
            }
            if (exists) continue;
            XmlElement el = doc.CreateElement("uses-permission");
            el.SetAttribute("name", AndroidNs, perm);
            root.PrependChild(el);
            added++;
        }

        if (added > 0)
        {
            doc.Save(manifestPath);
            Debug.Log($"[QuestCallBridge] Added {added} Android permission(s) to the manifest.");
        }
    }
}
#endif
