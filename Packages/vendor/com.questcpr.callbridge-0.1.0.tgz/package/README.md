# Quest CPR Call Bridge (Unity package)

> Hackathon simulation only. It calls only the demo phone number configured on the backend, never emergency services.

Press SOS in your Quest 3 app and three things happen:
1. The headset joins a private voice room.
2. The backend calls the "dispatcher" phone, which hears a short automated message with the coordinates.
3. The call is handed over, and the phone and headset can talk to each other live.

## Install (any Unity project, Unity 2022.3+)

**Option A, from a file:** Window → Package Manager → **+** → **Add package from tarball…** → choose
`com.questcpr.callbridge-0.1.0.tgz`.

**Option B, from git** (once the repo is on GitHub): Window → Package Manager → **+** → **Add package from git URL…** →
`https://github.com/<you>/<repo>.git?path=/unity-package/com.questcpr.callbridge`

## Use

1. Create an empty GameObject (for example `CallSystem`) and add the **QuestCallBridge** component.
2. Set **Server Url** to the backend's https address, for example `https://xxxx.trycloudflare.com`. Leave **Demo Key** empty
   unless the server has `REQUIRE_DEMO_KEY=true`.
3. Connect your SOS button's **On Click** (or your voice command) to **QuestCallBridge.StartEmergencyCall**.
4. Player Settings → Android → **Internet Access = Require**.
5. Build to the Quest. The first time, allow the microphone.

Other methods: `JoinAudioOnly()`, `ToggleMute()`, `HangUp()`,
`SetLocation(lat, lon, "device", accuracyMeters)`.

Events you can connect UI to: `onStatus(string)`, `onError(string)`, `onJoined`, `onDispatcherConnected`,
`onDispatcherLeft`, `onCallEnded`.

The Android permissions (INTERNET, RECORD_AUDIO, MODIFY_AUDIO_SETTINGS) are added to the build
automatically by `QuestCallBridgeManifestPatcher`.

## How it works

A hidden 1×1 Android WebView loads `<Server Url>/rescuer?embed=1`. That page uses WebRTC through the SignalWire
browser SDK to send and receive audio with the Quest's mic and speakers. Unity controls it through
`QuestCallBridge.java`. The SignalWire credentials stay on the server.

Live audio does not run in the Unity Editor, so test in a Quest build. You can also test the same page in any
browser at `<Server Url>/rescuer`.

`EmergencyCaller` is an optional HTTP-only SOS trigger with no audio.
