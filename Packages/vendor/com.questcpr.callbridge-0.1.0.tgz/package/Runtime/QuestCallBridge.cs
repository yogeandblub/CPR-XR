// QuestCallBridge.cs - Quest CPR Emergency Demo (HACKATHON SIMULATION ONLY)
//
// Live two-way AUDIO between the Quest 3 wearer and the simulated dispatcher.
//
//   StartEmergencyCall(): joins the audio room (mic + speakers), then asks the
//   backend to call the demo phone. The dispatcher hears the simulated report
//   privately, then is connected to this headset.
//
// Never calls emergency services: the backend only calls its own configured demo number.
//
// Setup (existing Unity project):
//   1. Copy QuestCallBridge.cs -> Assets/Scripts/
//      Copy Plugins/Android/QuestCallBridge.java -> Assets/Plugins/Android/
//   2. Add this component to any GameObject. Set Server Url (https tunnel URL, no
//      trailing slash) and Demo Key (DEMO_CLIENT_KEY from the server .env).
//   3. Wire your SOS button / voice command to StartEmergencyCall().
//   4. Android manifest needs RECORD_AUDIO, MODIFY_AUDIO_SETTINGS and INTERNET (see README).
//
// SECURITY NOTE: the demo key ships inside the APK; demo-grade only.

using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Text;
using UnityEngine;
using UnityEngine.Events;
#if UNITY_ANDROID
using UnityEngine.Android;
#endif

public class QuestCallBridge : MonoBehaviour
{
    [Header("Backend")]
    [Tooltip("e.g. https://xxxx.trycloudflare.com (no trailing slash)")]
    public string serverUrl = "https://YOUR-TUNNEL-DOMAIN";
    [Tooltip("Leave empty if the server has REQUIRE_DEMO_KEY=false; otherwise must match DEMO_CLIENT_KEY.")]
    public string demoKey = "";
    [Tooltip("Seconds to wait for the hidden call page to load.")]
    public float pageLoadTimeout = 20f;

    [Header("Events")]
    public UnityEvent<string> onStatus;          // human-readable progress
    public UnityEvent<string> onError;
    public UnityEvent onJoined;                  // headset is in the audio room
    public UnityEvent onDispatcherConnected;     // two-way audio is live
    public UnityEvent onDispatcherLeft;
    public UnityEvent onCallEnded;

    public bool IsBusy { get; private set; }
    public bool IsInCall { get; private set; }
    public bool IsMuted { get; private set; }

    // Optional extra SOS fields (validated by the server). Never invent location.
    private string _sosPayloadJson = "{}";

#if UNITY_ANDROID && !UNITY_EDITOR
    private AndroidJavaObject _bridge;
    private bool _pageReady;
#endif
    private readonly ConcurrentQueue<string> _inbox = new ConcurrentQueue<string>();

    [Serializable] private class BridgeMsg { public string type; public string message; }

    // ------------------------------------------------------------------ public API

    /// <summary>SOS: join audio room, then the backend calls the dispatcher.</summary>
    public void StartEmergencyCall() => Begin(true);

    /// <summary>Join the audio room without placing a call (for testing).</summary>
    public void JoinAudioOnly() => Begin(false);

    public void ToggleMute() => Exec("window.questBridge.mute()");

    public void HangUp() => Exec("window.questBridge.hangup()");

    /// <summary>Hook for a real location provider. source: "device", "estimated" or "simulated".</summary>
    public void SetLocation(double latitude, double longitude, string source, float accuracyMeters)
    {
        var ci = System.Globalization.CultureInfo.InvariantCulture;
        _sosPayloadJson = "{" +
            "\"latitude\":" + latitude.ToString("R", ci) +
            ",\"longitude\":" + longitude.ToString("R", ci) +
            ",\"location_source\":" + JsString(source) +
            ",\"location_accuracy_m\":" + accuracyMeters.ToString("R", ci) + "}";
    }

    public void ClearLocation() => _sosPayloadJson = "{}";

    // ------------------------------------------------------------------ internals

    private void Begin(bool withCall)
    {
        if (IsBusy || IsInCall) { Status("Already connecting or in a call."); return; }
        if (!serverUrl.StartsWith("https://") || serverUrl.Contains("YOUR-TUNNEL"))
        {
            Error("QuestCallBridge not configured: set an https Server Url.");
            return;
        }
        StartCoroutine(BeginRoutine(withCall));
    }

    private IEnumerator BeginRoutine(bool withCall)
    {
        IsBusy = true;
#if UNITY_ANDROID && !UNITY_EDITOR
        // 1. Microphone permission (Android runtime permission).
        if (!Permission.HasUserAuthorizedPermission(Permission.Microphone))
        {
            Status("Requesting microphone permission…");
            bool answered = false;
            var cb = new PermissionCallbacks();
            cb.PermissionGranted += _ => answered = true;
            cb.PermissionDenied += _ => answered = true;
#pragma warning disable CS0618
            cb.PermissionDeniedAndDontAskAgain += _ => answered = true;
#pragma warning restore CS0618
            Permission.RequestUserPermission(Permission.Microphone, cb);
            while (!answered) yield return null;
            if (!Permission.HasUserAuthorizedPermission(Permission.Microphone))
            {
                Error("Microphone permission denied. Enable it in the headset's app permissions.");
                IsBusy = false;
                yield break;
            }
        }

        // 2. Load the hidden call page once.
        if (_bridge == null)
        {
            using (var player = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
            {
                var activity = player.GetStatic<AndroidJavaObject>("currentActivity");
                _bridge = new AndroidJavaObject("com.questcpr.bridge.QuestCallBridge", activity, new Listener(_inbox));
            }
            _pageReady = false;
            Status("Loading call module…");
            _bridge.Call("load", serverUrl.TrimEnd('/') + "/rescuer?embed=1");
        }
        float t = 0f;
        while (!_pageReady && t < pageLoadTimeout) { t += Time.unscaledDeltaTime; yield return null; }
        if (!_pageReady)
        {
            Error("Call page did not load. Check the server/tunnel URL and headset internet.");
            IsBusy = false;
            yield break;
        }

        // 3. Join the room (and trigger SOS).
        Status(withCall ? "Connecting and calling dispatcher…" : "Joining audio room…");
        Exec($"window.questBridge.start({JsString(demoKey)}, {(withCall ? "true" : "false")}, {_sosPayloadJson})");
#else
        Error("Live audio calls only run in an Android (Quest) build. In the Editor, test with the /rescuer page in a browser.");
        yield return null;
#endif
        IsBusy = false;
    }

    private void Exec(string js)
    {
#if UNITY_ANDROID && !UNITY_EDITOR
        if (_bridge != null) _bridge.Call("exec", js);
#else
        Debug.Log("[QuestCallBridge] (editor) would run: " + js);
#endif
    }

    private void Update()
    {
        while (_inbox.TryDequeue(out var json)) Handle(json);
    }

    private void Handle(string json)
    {
        BridgeMsg m;
        try { m = JsonUtility.FromJson<BridgeMsg>(json); } catch { return; }
        if (m == null || string.IsNullOrEmpty(m.type)) return;

        switch (m.type)
        {
            case "ready":
#if UNITY_ANDROID && !UNITY_EDITOR
                _pageReady = m.message == "ok";
#endif
                if (m.message != "ok") Error("Call page loaded but the SignalWire SDK did not (internet?).");
                break;
            case "joined": IsInCall = true; Status("In audio room – waiting for dispatcher."); onJoined?.Invoke(); break;
            case "dispatcher_connected": Status("Dispatcher connected – talk now."); onDispatcherConnected?.Invoke(); break;
            case "dispatcher_left": Status("Dispatcher left the call."); onDispatcherLeft?.Invoke(); break;
            case "muted": IsMuted = true; Status("Muted."); break;
            case "unmuted": IsMuted = false; Status("Unmuted."); break;
            case "ended": IsInCall = false; IsMuted = false; Status("Call ended."); onCallEnded?.Invoke(); break;
            case "error": Error(m.message); break;
            default: Status(m.message); break;   // "status", "call_requested", ...
        }
    }

    private void Status(string msg)
    {
        if (string.IsNullOrEmpty(msg)) return;
        Debug.Log("[QuestCallBridge] " + msg);
        onStatus?.Invoke(msg);
    }

    private void Error(string msg)
    {
        Debug.LogError("[QuestCallBridge] " + msg);
        onError?.Invoke(msg);
    }

    private static string JsString(string s)
    {
        var sb = new StringBuilder("\"");
        foreach (char c in s ?? "")
        {
            if (c == '"' || c == '\\') sb.Append('\\').Append(c);
            else if (c < 0x20 || c == (char)0x2028 || c == (char)0x2029) sb.AppendFormat("\\u{0:x4}", (int)c);
            else sb.Append(c);
        }
        return sb.Append('"').ToString();
    }

    private void OnDestroy()
    {
#if UNITY_ANDROID && !UNITY_EDITOR
        if (_bridge != null) { _bridge.Call("destroy"); _bridge.Dispose(); _bridge = null; }
#endif
    }

#if UNITY_ANDROID && !UNITY_EDITOR
    // Called on an Android thread; queue to the Unity main thread.
    private class Listener : AndroidJavaProxy
    {
        private readonly ConcurrentQueue<string> _q;
        public Listener(ConcurrentQueue<string> q) : base("com.questcpr.bridge.QuestCallBridge$Listener") { _q = q; }
        public void onMessage(string json) => _q.Enqueue(json);
    }
#endif
}
