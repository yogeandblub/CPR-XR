// EmergencyCaller.cs - Quest CPR Emergency Demo (HACKATHON SIMULATION ONLY)
//
// Sends a simulated SOS to the demo backend, which calls ONE pre-configured,
// verified demo phone number. This script never dials any number itself and
// never contacts real emergency services. Not medically certified.
//
// Setup:
//   1. Add this component to a GameObject (e.g. "EmergencySystem").
//   2. Set Backend Url to https://YOUR-NGROK-DOMAIN (no trailing /sos).
//   3. Set Demo Key to the DEMO_CLIENT_KEY from the server's .env.
//   4. Wire a UI Button's OnClick (or your voice-command handler) to TriggerSOS().
//   5. Player Settings > Android > Internet Access = Require.
//
// SECURITY NOTE: the demo key is a shared secret baked into the APK. Anyone
// with the APK can extract it. Fine for a hackathon demo; NOT production auth.

using System;
using System.Collections;
using System.Globalization;
using System.Text;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Networking;

public class EmergencyCaller : MonoBehaviour
{
    [Header("Backend")]
    [Tooltip("Base URL, e.g. https://abc123.ngrok-free.app")]
    public string backendUrl = "https://YOUR-NGROK-DOMAIN";
    [Tooltip("Must match DEMO_CLIENT_KEY on the server. Demo-grade secret only.")]
    public string demoKey = "";
    public int timeoutSeconds = 20;

    [Header("Patient state (update from your CPR flow)")]
    public string patientStatus = "unconscious";   // unconscious | conscious | unknown
    public bool breathing = false;
    public string ageCategory = "adult";           // adult | child | infant | unknown

    [Header("Events (optional, for UI)")]
    public UnityEvent<string> onStatus;            // human-readable progress
    public UnityEvent<string> onCallAccepted;      // Twilio Call SID
    public UnityEvent<string> onError;             // error description

    public bool IsRequestPending { get; private set; }

    // Location: null until a real provider calls SetLocation(). Never invented.
    private double? _latitude;
    private double? _longitude;
    private string _locationSource = "simulated";  // device | estimated | simulated
    private float? _accuracyMeters;

    /// <summary>Hook for a future location provider. source: "device", "estimated" or "simulated".</summary>
    public void SetLocation(double latitude, double longitude, string source, float? accuracyMeters = null)
    {
        _latitude = latitude;
        _longitude = longitude;
        _locationSource = source;
        _accuracyMeters = accuracyMeters;
    }

    public void ClearLocation()
    {
        _latitude = null;
        _longitude = null;
        _accuracyMeters = null;
    }

    /// <summary>Connect to a UI Button or voice command ("SOS"). Safe to call repeatedly.</summary>
    public void TriggerSOS()
    {
        if (IsRequestPending)
        {
            Report("SOS already in progress - ignoring repeat activation.");
            return;
        }
        if (backendUrl.Contains("YOUR-NGROK-DOMAIN"))
        {
            Fail("EmergencyCaller is not configured (backendUrl).");
            return;
        }
        StartCoroutine(SendSOS());
    }

    private IEnumerator SendSOS()
    {
        IsRequestPending = true;
        // One key per activation: if the request is retried, the server won't call twice.
        string idempotencyKey = "quest-" + Guid.NewGuid().ToString("N");
        string json = BuildJson();
        string url = backendUrl.TrimEnd('/') + "/sos";

        Report("Sending simulated SOS...");

        using (var req = new UnityWebRequest(url, UnityWebRequest.kHttpVerbPOST))
        {
            req.uploadHandler = new UploadHandlerRaw(Encoding.UTF8.GetBytes(json));
            req.downloadHandler = new DownloadHandlerBuffer();
            req.timeout = timeoutSeconds;
            req.SetRequestHeader("Content-Type", "application/json");
            if (!string.IsNullOrEmpty(demoKey)) req.SetRequestHeader("X-Demo-Key", demoKey);
            req.SetRequestHeader("Idempotency-Key", idempotencyKey);
            req.SetRequestHeader("ngrok-skip-browser-warning", "true");

            yield return req.SendWebRequest();   // async, does not block the main thread

            string body = req.downloadHandler != null ? req.downloadHandler.text : "";
            long code = req.responseCode;

            if (req.result == UnityWebRequest.Result.Success && code == 200)
            {
                var resp = JsonUtility.FromJson<SosResponse>(body);
                if (resp != null && resp.ok)
                {
                    string mode = resp.mock ? " (MOCK - no phone rang)" : "";
                    Report($"Simulated dispatcher call requested{mode}. SID={resp.call_sid} status={resp.call_status}");
                    onCallAccepted?.Invoke(resp.call_sid);
                }
                else
                {
                    Fail($"Unexpected response: {body}");
                }
            }
            else if (code == 429)
            {
                Fail("Cooldown active - a demo call was placed recently. " + body);
            }
            else if (req.result == UnityWebRequest.Result.ConnectionError)
            {
                Fail($"Network error: {req.error}. Is the server/ngrok running?");
            }
            else
            {
                Fail($"SOS failed (HTTP {code}): {req.error} {body}");
            }
        }

        IsRequestPending = false;
    }

    private string BuildJson()
    {
        // Built manually because JsonUtility can't omit null location fields.
        var ci = CultureInfo.InvariantCulture;
        var sb = new StringBuilder();
        sb.Append("{\"event\":\"SOS\"");
        sb.Append(",\"patient_status\":\"").Append(Sanitize(patientStatus)).Append('"');
        sb.Append(",\"breathing\":").Append(breathing ? "true" : "false");
        sb.Append(",\"age_category\":\"").Append(Sanitize(ageCategory)).Append('"');
        if (_latitude.HasValue && _longitude.HasValue)
        {
            sb.Append(",\"latitude\":").Append(_latitude.Value.ToString("R", ci));
            sb.Append(",\"longitude\":").Append(_longitude.Value.ToString("R", ci));
            sb.Append(",\"location_source\":\"").Append(Sanitize(_locationSource)).Append('"');
            if (_accuracyMeters.HasValue)
                sb.Append(",\"location_accuracy_m\":").Append(_accuracyMeters.Value.ToString("R", ci));
        }
        sb.Append('}');
        return sb.ToString();
    }

    // Values are fixed enums server-side; strip anything that could break JSON.
    private static string Sanitize(string s) =>
        string.IsNullOrEmpty(s) ? "unknown" : s.Replace("\\", "").Replace("\"", "");

    private void Report(string msg)
    {
        Debug.Log("[EmergencyCaller] " + msg);
        onStatus?.Invoke(msg);
    }

    private void Fail(string msg)
    {
        Debug.LogError("[EmergencyCaller] " + msg);
        onError?.Invoke(msg);
    }

    [Serializable]
    private class SosResponse
    {
        public bool ok;
        public bool mock;
        public string call_sid;
        public string call_status;
        public string error;
    }
}
