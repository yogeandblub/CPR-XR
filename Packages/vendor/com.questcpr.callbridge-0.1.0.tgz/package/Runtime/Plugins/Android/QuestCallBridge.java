// QuestCallBridge.java - Quest CPR Emergency Demo (HACKATHON SIMULATION ONLY)
//
// Hosts the backend's /rescuer page in a hidden, 1x1 Android WebView inside the
// Unity activity. The page uses WebRTC (SignalWire browser SDK) for live audio
// through the Quest microphone and speakers. Unity drives it via exec(), and the
// page reports back through window.UnityBridge.postMessage(json) -> Listener.
//
// Unity compiles .java files under Assets/Plugins/Android automatically.

package com.questcpr.bridge;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

public class QuestCallBridge {
    private static final String TAG = "QuestCallBridge";

    /** Implemented in C# with AndroidJavaProxy. */
    public interface Listener {
        void onMessage(String json);
    }

    private final Activity activity;
    private final Listener listener;
    private WebView web;
    private String allowedHost;

    public QuestCallBridge(Activity activity, Listener listener) {
        this.activity = activity;
        this.listener = listener;
    }

    /** Loads the rescuer page (must be https). Safe to call again to reload. */
    public void load(final String url) {
        final Uri uri = Uri.parse(url);
        if (!"https".equals(uri.getScheme())) {
            emit("error", "Rescuer URL must be https (microphone requires a secure page).");
            return;
        }
        allowedHost = uri.getHost();
        activity.runOnUiThread(new Runnable() {
            @Override public void run() {
                if (web == null) create();
                web.loadUrl(url);
            }
        });
    }

    /** Runs JavaScript in the page, e.g. window.questBridge.start(...). */
    public void exec(final String js) {
        activity.runOnUiThread(new Runnable() {
            @Override public void run() {
                if (web != null) web.evaluateJavascript(js, null);
            }
        });
    }

    public void destroy() {
        activity.runOnUiThread(new Runnable() {
            @Override public void run() {
                if (web == null) return;
                web.evaluateJavascript("window.questBridge && window.questBridge.hangup()", null);
                ViewGroup parent = (ViewGroup) web.getParent();
                if (parent != null) parent.removeView(web);
                web.destroy();
                web = null;
            }
        });
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void create() {
        web = new WebView(activity);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);   // remote audio must autoplay

        web.setBackgroundColor(Color.TRANSPARENT);
        web.setWebViewClient(new WebViewClient());      // keep navigation inside the WebView
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                // Grant ONLY microphone, and ONLY to our own backend's host.
                String host = request.getOrigin() != null ? request.getOrigin().getHost() : null;
                boolean audioOnly = true;
                for (String r : request.getResources()) {
                    if (!PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) audioOnly = false;
                }
                if (allowedHost != null && allowedHost.equals(host) && audioOnly) {
                    request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                } else {
                    Log.w(TAG, "Denied web permission request from " + host);
                    request.deny();
                }
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage m) {
                Log.d(TAG, "JS: " + m.message());
                return true;
            }
        });
        web.addJavascriptInterface(new JsBridge(), "UnityBridge");

        // 1x1 and fully transparent: the WebView must be attached to keep running,
        // but it is never visible in VR (Unity renders through the XR compositor).
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(1, 1);
        web.setAlpha(0f);
        web.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        ViewGroup root = (ViewGroup) activity.findViewById(android.R.id.content);
        root.addView(web, lp);
    }

    private void emit(String type, String message) {
        String safe = message == null ? "" : message.replace("\\", "\\\\").replace("\"", "\\\"");
        deliver("{\"type\":\"" + type + "\",\"message\":\"" + safe + "\"}");
    }

    private void deliver(String json) {
        try {
            if (listener != null) listener.onMessage(json);
        } catch (Throwable t) {
            Log.e(TAG, "Listener failed", t);
        }
    }

    private class JsBridge {
        @JavascriptInterface
        public void postMessage(String json) {
            deliver(json);
        }
    }
}
